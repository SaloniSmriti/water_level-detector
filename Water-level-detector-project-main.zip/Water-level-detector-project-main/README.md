# Water-level-detector-project
An IOT based project which detects the level of water using ultrasonic sensor.
